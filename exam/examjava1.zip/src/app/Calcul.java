package app;

public interface Calcul {
    void CalculerTotal();
}
